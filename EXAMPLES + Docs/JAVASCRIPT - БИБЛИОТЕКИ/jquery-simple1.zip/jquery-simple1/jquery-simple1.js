$(document).ready(function(){
    $("p").click(function(){
        $(this).hide();
    });
});